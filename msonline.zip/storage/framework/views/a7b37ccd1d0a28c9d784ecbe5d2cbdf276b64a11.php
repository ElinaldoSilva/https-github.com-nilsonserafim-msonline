<html>
    <header>
        <title>PDF</title>
        <meta http-equiv="Content-Language" content="th" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <style>
            body {
                font-size: 28px;
            }
        </style>
    </header>

    <body>
        <p>TESTE</p>Primeira linha mPDF
    </body>

</html>
<?php /**PATH C:\wamp64\www\msonline\resources\views/pdf.blade.php ENDPATH**/ ?>