<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <link rel="shortcut icon" type="image/ico" href="<?php echo e(asset('img/favicon.ico')); ?>">

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <style>
            .title {
                font-weight: 700;
                color: #1b49b9;
                font-size: 24px;
            }    
            .cont-01 {
                display: flex;
                flex-direction: column;
            }                
            }
            .login-logo {
                margin-top: -6px;
            }
            @media (max-width: 591px) 
            {
                .login-logo  {
                    margin-top: 3px;
                }
                .cont-01  {
                    flex-direction: column-reverse;
                }
            }
            <?php echo $__env->yieldContent('style'); ?>;
        </style>

    </head>

    <body>

        <div class="cont-01">
          <div class="">
            <?php if(Route::has('login')): ?>
                <div class="pt-3 pr-4 text-right">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('login')); ?>" class="ml-4 text-sm text-gray-700 underline">Logout</a>

                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>

                    <?php else: ?>
                        <?php if(!Request::is('login')): ?>
                            <a href="<?php echo e(route('login')); ?>" class="mr-4 semibold c-gray underline">Login</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
          </div>

          <header class="header-desktop3 d-lg-block" style="height:68px;" >
            <div class="section__content--p35">
                <div class="login-logo">
                    <a href="/" ><img class="img-fluid img-responsive"  style="max-height:74px;" src="<?php echo e(asset('img/logo.png')); ?>" alt="Cemitério e Crematório do Catumbi"></a>
                </div>
            </div>

          </header>
        </div>
        <br>

        <?php echo $__env->yieldContent('content'); ?>

    </body>

</html>
<?php /**PATH C:\wamp64\www\msonline\resources\views/templates/template_login.blade.php ENDPATH**/ ?>