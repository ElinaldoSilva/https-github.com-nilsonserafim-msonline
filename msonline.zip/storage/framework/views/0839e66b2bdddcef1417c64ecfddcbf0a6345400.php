<?php $__env->startSection('title'); ?> Corretores <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container container-800">
    <div class="row justify-content-center mt-md-4">
        <div class="col-md-11">
            <div class="card shadow">
                <div class="card-header text-center title ft-20 bold"><?php echo e(__('CADASTRO DE CORRETORES')); ?>

                <?php if(isset($corretor)): ?> <h4 class="text-center" style="color:#f1a951; margin-bottom: 0;">Atualização</h4><?php endif; ?>
                </div>    

                <div class="card-body ">
                  <?php if(isset($corretor)): ?>
                    <form method="post" action="<?php echo e(url('corretor/' . $corretor->id)); ?>">
                        <?php echo method_field('PUT'); ?>
                  <?php else: ?>
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                  <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="name" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Nome')); ?></label>

                            <div class="col-md-8">
                                <input id="name" type="text" maxlength="100" class="form-control maiusculo <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e($corretor->name ?? ''); ?>" required autocomplete="name" autofocus>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="nivel" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Funerária')); ?></label>

                            <div class="col-md-8">
                                <select class="custom-select " id="funerariaId" name="funerariaId">
                                    <?php if(!isset($corretor)): ?> 
                                        <option selected value="0">selecione o funerária...</option>
                                    <?php endif; ?>    
                                    <?php $__currentLoopData = $funerarias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funeraria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e((isset($corretor) && $funeraria->FunerariaId==$corretor->funerariaId) ? "selected" : ''); ?> value="<?php echo e($funeraria->FunerariaId); ?>"><?php echo e(strtoupper($funeraria->Nome)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>

                            <div class="col-md-8">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" required  value="<?php echo e($corretor->email ?? ''); ?>" autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="nivel" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Nível')); ?></label>

                            <div class="col-md-8">
                                <select class="custom-select " id="nivel" name="nivel">
                                    <option value="1" <?php echo e((isset($corretor) && $corretor->nivel==1) ? "selected" : ''); ?>>Administrador</option>
                                    <option value="9" <?php echo e(((isset($corretor) && $corretor->nivel==9) || !isset($corretor) ) ? "selected" : ''); ?>>Corretor</option>
                                </select>
                            </div>
                        </div>

                      <?php if(isset($corretor)): ?>
                        <div class="form-group row">
                            <label for="password" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Status')); ?></label>
                            <div class="form-control d-contents" >
                                <div class="custom-control custom-radio ml-3 my-1">
                                    <input type="radio" class="custom-control-input" <?php echo e(( ($corretor->status!=0) ? "checked" : "")); ?> id="ativo" name="status" value="1" >
                                    <label class="custom-control-label p-0 px-1" for="ativo">Ativo</label>
                                </div>
                                <div class="custom-control custom-radio ml-3 my-1">
                                    <input type="radio" class="custom-control-input" <?php echo e(( ($corretor->status==0) ? "checked" : "")); ?> id="desativado" name="status" value="2">
                                    <label class="custom-control-label p-0 px-1" for="desativado">Desativado</label>
                                </div>
                            </div>
                        </div>
                      <?php else: ?>  
                        <div class="form-group row">
                            <label for="password" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Senha')); ?></label>

                            <div class="col-md-6">
                                <input id="password"  name="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="new-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Confirme a Senha')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>
                      <?php endif; ?>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php if(isset($corretor)): ?> <?php echo e(__('Atualizar')); ?> <?php else: ?> <?php echo e(__('Registrar')); ?> <?php endif; ?>
                                </button>
                            </div>
                        </div> 
                    </form>
                </div>
            </div>
        </div>
    </div>
    <br><br>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
 // <script>
    //  Transforma minusculo em maisculo
    //
    var inputs = $(".maiusculo");
    inputs.on("input", function (event) {
        event.target.value = (event.target.value).toUpperCase();
    });   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.template_bs5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\msonline\resources\views/auth/register.blade.php ENDPATH**/ ?>