<html>
    <header>
        <title>Sepultamento</title>
        <meta http-equiv="Content-Language" content="th" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <style>
            body {
                font-size: 30px;
            }
            p {
                margin-bottom: 10px;
            }
        </style>
    </header>

    <body>
        <div>
            <p style="text-align:center;"><img src= "{{ asset('img/logo2.png') }}" style="width: 140px; margin-bottom:80px;"></p>
            <p>Falecido: <strong>{{ $regSepultamento['falecido'] }}</strong></p>
            <p>Data Sepultamento:&nbsp;&nbsp;<strong>{{ $regSepultamento['data'] }}</strong>&nbsp;&nbsp;&nbsp;Hora: <strong>{{ $regSepultamento['hora'] }}</strong></p>
            <p>Funeraria:  {{ $regSepultamento['funeraria'] }}</p>
            <p>Cemitério: São Francisco de Paula - Catumbi</p>
        </div>
    </body>

</html>
